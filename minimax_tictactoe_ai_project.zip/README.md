# MINIMAX // AI Tic-Tac-Toe

A futuristic, browser-based demonstration project for an AI case study on the Minimax algorithm.

## Features

- Human vs AI Tic-Tac-Toe
- Optimal Minimax mode
- Depth-Limited mode
- Random baseline mode
- Live nodes visited
- Search depth
- Utility score
- Decision time
- Candidate move visualization
- MAX/MIN explanation
- Utility scoring (+10 / 0 / -10)
- Responsive futuristic UI
- No backend required

## How to run

### Simplest
Double-click `index.html`.

### Recommended
From this folder run:

```bash
python3 -m http.server 5500
```

Then open:

http://localhost:5500

## Suggested classroom demonstration

1. Start in `OPTIMAL • MINIMAX`.
2. Make a move that creates multiple possibilities.
3. Point to the **Nodes Visited**, **Search Depth**, and **Best Score**.
4. Show the **Search Tree Explorer**.
5. Explain:
   - MAX = AI
   - MIN = opponent
   - +10 = AI win
   - 0 = draw
   - -10 = AI loss
6. Switch to `RANDOM BASELINE` and demonstrate that random play does not reason about future responses.
7. Switch back to Minimax and explain why exhaustive search works well for Tic-Tac-Toe.
