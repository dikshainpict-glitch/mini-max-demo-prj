const boardEl = document.getElementById('board');
const statusText = document.getElementById('statusText');
const turnBadge = document.getElementById('turnBadge');
const difficultyEl = document.getElementById('difficulty');
const treeEl = document.getElementById('tree');

let human = 'X', ai = 'O', board = Array(9).fill('');
let gameOver = false, thinking = false;
let scores = {human:0, ai:0, draw:0};
let lastAnalysis = {nodes:0, depth:0, score:null, ms:null, move:null, branches:[]};

const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];

function winner(b){
  for(const [a,c,d] of wins){
    if(b[a] && b[a]===b[c] && b[a]===b[d]) return {player:b[a], line:[a,c,d]};
  }
  if(b.every(Boolean)) return {player:'draw',line:[]};
  return null;
}
function emptyCells(b){return b.map((v,i)=>v?null:i).filter(v=>v!==null)}
function render(){
  boardEl.innerHTML='';
  board.forEach((v,i)=>{
    const cell=document.createElement('button');
    cell.className='cell '+(v?v.toLowerCase()+' filled':'');
    cell.textContent=v;
    cell.onclick=()=>humanMove(i);
    boardEl.appendChild(cell);
  });
  const res=winner(board);
  if(res && res.line.length) res.line.forEach(i=>boardEl.children[i].classList.add('win'));
}
function updateUI(){
  document.getElementById('nodes').textContent=lastAnalysis.nodes.toLocaleString();
  document.getElementById('depth').textContent=lastAnalysis.depth;
  document.getElementById('bestScore').textContent=lastAnalysis.score===null?'—':(lastAnalysis.score>0?'+':'')+lastAnalysis.score;
  document.getElementById('decisionTime').textContent=lastAnalysis.ms===null?'—':lastAnalysis.ms+' ms';
  document.getElementById('treeCount').textContent=(lastAnalysis.branches.length?lastAnalysis.branches.length+' CANDIDATE STATES':'0 STATES');
}
function terminalScore(b, depth, maximizingAI){
  const r=winner(b);
  if(!r) return null;
  if(r.player===ai) return 10-depth;
  if(r.player===human) return depth-10;
  return 0;
}

function minimax(b, maximizing, depth, stats){
  stats.nodes++;
  stats.depth=Math.max(stats.depth, depth);
  const t=terminalScore(b,depth,maximizing);
  if(t!==null) return t;
  const moves=emptyCells(b);
  if(maximizing){
    let best=-Infinity;
    for(const i of moves){
      b[i]=ai;
      best=Math.max(best,minimax(b,false,depth+1,stats));
      b[i]='';
    }
    return best;
  } else {
    let best=Infinity;
    for(const i of moves){
      b[i]=human;
      best=Math.min(best,minimax(b,true,depth+1,stats));
      b[i]='';
    }
    return best;
  }
}

function getOptimalMove(){
  const start=performance.now(), stats={nodes:0,depth:0};
  let bestScore=-Infinity, bestMove=null, branches=[];
  for(const i of emptyCells(board)){
    board[i]=ai;
    const score=minimax(board,false,1,stats);
    board[i]='';
    branches.push({i,score});
    if(score>bestScore){bestScore=score;bestMove=i;}
  }
  const ms=Math.max(1,Math.round(performance.now()-start));
  lastAnalysis={nodes:stats.nodes,depth:stats.depth,score:bestScore,ms,move:bestMove,branches};
  return bestMove;
}
function getDepthLimitedMove(limit=3){
  const start=performance.now(), stats={nodes:0,depth:0};
  function search(b,maximizing,depth){
    stats.nodes++; stats.depth=Math.max(stats.depth,depth);
    const t=terminalScore(b,depth,maximizing); if(t!==null)return t;
    if(depth>=limit){
      // simple heuristic: center + corners + lines
      let val=0;
      if(b[4]===ai) val+=2; if(b[4]===human) val-=2;
      [0,2,6,8].forEach(i=>{if(b[i]===ai)val++; if(b[i]===human)val--});
      return val;
    }
    const moves=emptyCells(b);
    if(maximizing){let best=-Infinity; for(const i of moves){b[i]=ai;best=Math.max(best,search(b,false,depth+1));b[i]=''} return best}
    let best=Infinity; for(const i of moves){b[i]=human;best=Math.min(best,search(b,true,depth+1));b[i]=''} return best;
  }
  let best=-Infinity,bestMove=null,branches=[];
  for(const i of emptyCells(board)){board[i]=ai;let s=search(board,false,1);board[i]='';branches.push({i,score:s});if(s>best){best=s;bestMove=i}}
  lastAnalysis={nodes:stats.nodes,depth:stats.depth,score:best,ms:Math.max(1,Math.round(performance.now()-start)),move:bestMove,branches};
  return bestMove;
}
function randomMove(){
  const moves=emptyCells(board), i=moves[Math.floor(Math.random()*moves.length)];
  lastAnalysis={nodes:1,depth:1,score:0,ms:1,move:i,branches:moves.map(x=>({i:x,score:0}))};
  return i;
}
function humanMove(i){
  if(gameOver||thinking||board[i]) return;
  board[i]=human; render();
  if(checkEnd()) return;
  aiTurn();
}
function checkEnd(){
  const r=winner(board);
  if(!r)return false;
  gameOver=true;
  if(r.player==='draw'){scores.draw++;statusText.textContent='DRAW • Both agents reached a neutral outcome.';turnBadge.textContent='DRAW';}
  else if(r.player===human){scores.human++;statusText.textContent='YOU WIN • The AI failed to minimize the outcome.';turnBadge.textContent='HUMAN WIN';}
  else {scores.ai++;statusText.textContent='AI WINS • Minimax found the strongest line.';turnBadge.textContent='AI WIN';}
  document.getElementById('humanScore').textContent=scores.human;
  document.getElementById('drawScore').textContent=scores.draw;
  document.getElementById('aiScore').textContent=scores.ai;
  return true;
}
function aiTurn(){
  thinking=true; turnBadge.textContent='AI THINKING'; statusText.textContent='Exploring future states…';
  document.getElementById('analysisState').textContent='SEARCHING';
  setTimeout(()=>{
    let move;
    if(difficultyEl.value==='optimal') move=getOptimalMove();
    else if(difficultyEl.value==='depth') move=getDepthLimitedMove(3);
    else move=randomMove();
    if(move!==null) board[move]=ai;
    thinking=false; render(); updateUI(); renderTree();
    document.getElementById('analysisState').textContent='DECISION READY';
    const label=move===null?'none':`cell ${move+1}`;
    document.getElementById('decisionText').textContent =
      difficultyEl.value==='optimal'
      ? `Minimax evaluated ${lastAnalysis.branches.length} immediate candidate moves and selected ${label} with a utility of ${lastAnalysis.score}.`
      : `The ${difficultyEl.options[difficultyEl.selectedIndex].text.toLowerCase()} evaluated the available states and selected ${label}.`;
    if(!checkEnd()){turnBadge.textContent='YOUR TURN';statusText.textContent='Your move. The AI will respond.';}
  },220);
}
function renderTree(){
  if(!lastAnalysis.branches.length){treeEl.innerHTML='<div class="tree-empty">MAKE A MOVE TO VISUALIZE THE SEARCH TREE</div>';return}
  const root=document.createElement('div');root.className='tree-root';
  root.innerHTML='<div class="root-node">CURRENT STATE • MAX</div>';
  const branches=document.createElement('div');branches.className='branches';
  const max=Math.max(...lastAnalysis.branches.map(x=>x.score));
  lastAnalysis.branches.slice(0,9).forEach(x=>{
    const b=document.createElement('div');b.className='branch '+(x.score===max?'best':'');
    const line=document.createElement('div');line.className='branch-line';
    const node=document.createElement('div');node.className='move-node';
    const s=x.score>0?'pos':x.score<0?'neg':'zero';
    node.innerHTML=`<div class="move">MOVE ${x.i+1}</div><div class="score ${s}">${x.score>0?'+':''}${x.score}</div>`;
    b.append(line,node);branches.appendChild(b);
  });
  root.appendChild(branches);treeEl.innerHTML='';treeEl.appendChild(root);
}
function reset(){
  board=Array(9).fill('');gameOver=false;thinking=false;
  lastAnalysis={nodes:0,depth:0,score:null,ms:null,move:null,branches:[]};
  statusText.textContent='Choose a move.';turnBadge.textContent='YOUR TURN';
  document.getElementById('analysisState').textContent='WAITING';
  document.getElementById('decisionText').textContent='Make a move to activate the decision engine.';
  render();updateUI();renderTree();
  if(human==='O') aiTurn();
}
document.querySelectorAll('.segmented button').forEach(btn=>btn.onclick=()=>{
  document.querySelectorAll('.segmented button').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active'); human=btn.dataset.symbol; ai=human==='X'?'O':'X'; reset();
});
document.getElementById('newGame').onclick=reset;
difficultyEl.onchange=reset;
render();updateUI();renderTree();
